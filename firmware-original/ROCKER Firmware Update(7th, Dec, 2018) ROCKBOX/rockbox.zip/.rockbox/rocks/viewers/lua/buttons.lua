-- Don't change this file!
-- It is automatically generated of button.h $Revision$
rb.buttons = {
	BUTTON_UP = 4,
	BUTTON_SELECT = 16,
	BUTTON_POWER = 128,
	BUTTON_VOLDOWN = 32,
	BUTTON_DOWN = 8,
	BUTTON_LEFT = 1,
	BUTTON_RIGHT = 2,
	BUTTON_MAIN = 255,
	BUTTON_VOLUP = 64,
	BUTTON_REL = 33554432,
	BUTTON_REPEAT = 67108864,
	BUTTON_TOUCHSCREEN = 134217728,
}
